<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>О нас</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <h1>О нас</h1>
<p style="font-size: 18px;">Наша компания рада приветствовать вас на борту нашего роскошного теплохода, который отправляется в увлекательное путешествие по реке Обь в городе Барнаул. Мы предлагаем вам уникальную возможность насладиться красотой сибирской природы и провести незабываемый отдых на воде.</p><br>

<p style="font-size: 18px;">Наша компания была основана группой энтузиастов, которые любят реку Обь и хотят поделиться своей любовью с другими. Мы гордимся тем, что можем предложить нашим гостям комфортные и безопасные прогулки на теплоходе, которые позволят им открыть для себя новые горизонты и создать незабываемые воспоминания.</p>

<p style="font-size: 18px;">Наши теплоходы оснащены современным оборудованием и соответствуют всем требованиям безопасности. Мы предлагаем различные маршруты, которые позволят вам увидеть самые красивые места реки Обь и узнать историю города Барнаула. На борту нашего теплохода вы сможете насладиться вкусной едой и напитками, а также насладиться живой музыкой и развлечениями.</p>

<p style="font-size: 18px;">Наша команда состоит из профессионалов, которые любят свою работу и стремятся сделать каждый рейс незабываемым. Мы рады видеть вас на борту нашего теплохода и готовы сделать все возможное, чтобы ваше путешествие было комфортным и приятным.</p>

<p style="font-size: 18px;">Присоединяйтесь к нам и откройте для себя новые горизонты на реке Обь!</p><br><br>
    </div>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="container w-50">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/3.jpg" class="d-block w-100 h-200" alt="">
                </div>
                <div class="carousel-item">
                    <img src="img/4.jpg" class="d-block w-100 h-200" alt="">
                </div>
                <div class="carousel-item">
                    <img src="img/5.jpg" class="d-block w-100 h-200" alt="">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        </div>
        <div style="height: ;">   </div>
    <?php include 'footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
