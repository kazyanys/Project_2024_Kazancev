<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Каталог</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<style type="text/css">
    .card {
    height: 100%;
    }

    .card-img-top {
        width: 100%;
        height: 250px;
        object-fit: cover;
    }
    .row{
        margin-bottom: 100px;
    }
</style>

    <?php include 'header.php'; ?>
    <div class="container">
        <h1>Каталог</h1>
        <div class="row">
            <?php
                $conn = new mysqli('localhost', 'root', '', 'altai_master');
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT id, name, price, image FROM products";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='col-md-4 mb-4'>
                                <div class='card'>
                                    <img src='".$row["image"]."' class='card-img-top' alt='".$row["name"]."'>
                                    <div class='card-body'>
                                        <h5 class='card-title'>".$row["name"]."</h5>
                                        <p class='card-text'>Цена: ".$row["price"]." руб.</p>
                                        <a href='product.php?id=".$row["id"]."' class='btn btn-primary'>Подробнее</a>
                                    </div>
                                </div>
                              </div>";
                    }
                } else {
                    echo "0 results";
                }
                $conn->close();
            ?>
        </div>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
