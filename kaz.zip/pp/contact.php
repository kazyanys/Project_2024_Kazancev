<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Контакты</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <h1>Контакты</h1>
        <p>Алтайский край, г. Барнаул, ул. Пушкина, д. 1</p>
        <p>Телефон: +7(3852)12-12-12, +7(3852)21-21-21</p>
        <p>Режим работы:<br> Пн-Вс с 9-00 до 20-00</p>
    </div>
    <div class="container" style="margin-bottom: 5%;">
        <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Abd8282cd59ead1b0dbde55561f368d0989e0d72774f6263b4a45c0bf433e00fa&amp;width=100%25&amp;height=600&amp;lang=ru_RU&amp;scroll=true"></script>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
