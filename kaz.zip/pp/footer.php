
<footer class="footer mt-auto py-3 sticky-bottom" style="background-color: #0093b9;">
    <div class="container">
        <span style="color: white;">&copy; 2024 Прогулки на теплоходе по Оби.</span>
    </div>
</footer>
