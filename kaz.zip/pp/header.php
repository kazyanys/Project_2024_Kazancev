<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #0093b9;">
    <a class="navbar-brand" href="index.php"><img src="img/logo.png" style="width: 100px;"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Главная</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="about.php">О нас</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="contact.php">Контакты</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="catalog.php">Каталог</a>
            </li>
            <?php
                session_start();
                if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true){
                    echo '<li class="nav-item"><a class="nav-link" href="logout.php">Выйти</a></li>';
                } else {
                    echo '<li class="nav-item"><a class="nav-link" href="login.php">Войти</a></li>';
                }
            ?>
        </ul>
    </div>
</nav>
