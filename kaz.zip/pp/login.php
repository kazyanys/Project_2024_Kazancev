<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Вход</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<style type="text/css">
 html, body {
    height: 100%;
    margin: 0;
}

.d-flex {
    display: flex;
}

.justify-content-center {
    justify-content: center;
}

.align-items-center {
    align-items: center;
}

.min-vh-100 {
    min-height: 100vh;
}

.card {
    width: 100%;
    max-width: 400px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
   
</style>
    <?php include 'header.php'; ?>
    <div class="d-flex justify-content-center align-items-center min-vh-100">
        <div class="card p-4">
            <h2>Вход</h2>
            <form action="login.php" method="post">
                <div class="form-group">
                    <label>Имя пользователя</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Пароль</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Войти">
                </div>
                <div class="form-group">
                    <p>У вас еще нет аккаунта? <a href="register.php">Регистрация</a></p>
                </div>
            </form>
        </div>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $conn = new mysqli('localhost', 'root', '', 'altai_master');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT id, is_admin FROM users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['loggedin'] = true;
        $_SESSION['id'] = $row['id'];
        $_SESSION['username'] = $username;
        $_SESSION['is_admin'] = $row['is_admin'];
        header("location: index.php");
    } else {
        echo "Invalid username or password.";
    }
    $conn->close();
}
?>
