<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Товар</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .product-container {
            margin-top: 20px;
        }
        .product-image {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
        .product-details {
            padding: 20px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
        }
        .product-price {
            font-size: 1.5em;
            color: #28a745;
            margin-bottom: 20px;
        }
        .costyl{
            height: 50px;
        }
        .card {
        height: 100%;
        }
    
        .card-img-top {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <div style="height: 50px;"></div>
    <div class="container product-container">
        <?php
            $conn = new mysqli('localhost', 'root', '', 'altai_master');
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $id = intval($_GET['id']);
            $sql = "SELECT name, description, price, dimensions, image FROM products WHERE id = $id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "
                    <div class='row'>
                        <div class='col-md-6'>
                            <img src='".$row["image"]."' class='img-fluid product-image' alt='".$row["name"]."'>
                        </div>
                        <div class='col-md-6'>
                            <div class='product-details'>
                                <h1>".$row["name"]."</h1>
                                <p>".$row["description"]."</p>
                                <p class='product-price'>Цена: ".$row["price"]." руб.</p>
                                <p>Условия для прогулки: ".$row["dimensions"]."</p>
                                <button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal'>Купить</button>                               
                            </div>
                        </div>
                    </div>";
                }
            } else {
                echo "<div class='alert alert-warning' role='alert'>Товар не найден.</div>";
            }
            $conn->close();
        ?>
    </div>

        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Купить</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Для покупки билетов вы можете связаться с нами по номерам:<br>+7(3852)12-12-12<br>+7(3852)21-21-21<br>или посетить Речной вокзал по адресу г. Барнаул, ул. Пушкина, д. 1
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
                    </div>
                </div>
            </div>
        </div>

    <div class="container">
        <h1 style="margin-top: 15px;">Больше товаров</h1>
        <div class="row">
            <?php
                $conn = new mysqli('localhost', 'root', '', 'altai_master');
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT id, name, price, image FROM products";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    $count = 0;
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='col-md-4'>
                                <div class='card'>
                                    <img src='".$row["image"]."' class='card-img-top' alt='".$row["name"]."'>
                                    <div class='card-body'>
                                        <h5 class='card-title'>".$row["name"]."</h5>
                                        <p class='card-text'>Цена: ".$row["price"]." руб.</p>
                                        <a href='product.php?id=".$row["id"]."' class='btn btn-primary'>Подробнее</a>
                                    </div>
                                </div>
                              </div>";

                        $count++;

                        if ($count >= 3) {
                            break;
                        }
                    }
                } else {
                    echo "0";
                }
                $conn->close();
            ?>
        </div>
    </div>

        <div class="costyl"></div>
    <?php include 'footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
